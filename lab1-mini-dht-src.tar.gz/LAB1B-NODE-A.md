# 实验 1B 部署方案（甲：节点 A 与部署集成）

单人准备版：本文档覆盖甲方九项任务中所有可以提前完成的文件与流程。
`<MACHINE-A-IP>` / `<MACHINE-B-IP>` / `<MACHINE-C-IP>` 为占位符，与组员（或自己）确定三台 CVM 后全局替换。

## 1. 环设计：node_id、端口、机器与前驱/后继环

### 1.1 节点与机器分配

| node_id | 监听端口 | 所在机器（占位符） | 环位置 = SHA-256(node_id) 前 8 字节 | 前驱 | 后继 |
|---|---|---|---|---|---|
| node-a | 19001 | `<MACHINE-A-IP>`（另承载 pricing、trip、ride-client） | `0x66570ff05a207404` | node-c | node-b |
| node-b | 19001 | `<MACHINE-B-IP>` | `0x93ef37c615713822` | node-a | node-c |
| node-c | 19001 | `<MACHINE-C-IP>` | `0x092cd5e29db96478` | node-b | node-a |

三节点环在哈希空间 `[0, 2^64)` 上按位置排序为 **node-c → node-a → node-b**；顺时针后继链：

```text
succ 方向（顺时针，成环回绕）：

  node-a ──succ──► node-b ──succ──► node-c ──succ──► node-a
    ▲                                                  │
    └────────────────── wrap-around ◄──────────────────┘
```

### 1.2 放置与路由规则

- 节点位置 = `SHA-256(node_id)` 前 8 字节（大端，见 `src/dht_ring.h` 的 `Hash64`）。
- key 的 owner = 环上从 `Hash64(key)` 出发顺时针遇到的第一个节点（没有则回绕到最小位置节点）。
- **路由只沿后继转发**：收到不属于自己 key 的节点把它转发给自己的后继，直到 owner 处理。因此每个节点只需知道后继一个地址，全部 node_id 通过启动参数 `--ring_nodes=node-a,node-b,node-c` 静态配置。
- 客户端（trip-service）**固定以 node-a 为 DHT 入口**，不知道其它节点。

### 1.3 固定测试 key 的预期落点（报告取证用）

| key | Hash64(key) | owner | 从 node-a 入口的路径 |
|---|---|---|---|
| `trip:trip-000001` | `0x7d3033a0e73cd768` | node-b | node-a → node-b（1 跳） |
| `trip:trip-000002` | `0x10629339f596b080` | node-a | node-a 本地存储（0 跳） |
| `trip:trip-000003` | `0xfe9ff1394c5245c5` | node-c | node-a → node-b → node-c（2 跳） |

创建前三笔订单即可让数据分布在全部三个节点上；`dht-node-*` 日志中的 `put key=... owner=... hops=...` 与上表逐一对应。

## 2. CVM 准备（每台机器相同，重复三次）

按根目录 `README.md` 第 2 节"方案 A"执行，要点：

1. 腾讯云按量计费 CVM ×3，Ubuntu Server 24.04 LTS x86_64，2 核 4 GiB；安全组放行 TCP 22（限自己的公网 IP）。
2. **安全组必须放行三台机器之间的 TCP 19001**（入站规则来源填另外两台机器的地址；同 VPC 用内网地址更省流量，否则用公网地址）。只放行 22 时节点之间会连不通，表现为 `dht put` 转发到后继失败。不需要开放 Docker 2375 或 18002。
3. 三台机器**互通地址**确定后记录下来（内网 IP 优先，不在同一地域时用公网 IP），替换本文所有占位符。
4. 每台安装 Docker 与 Compose v2 并加入 docker 组：

   ```bash
   sudo apt update
   sudo apt install -y docker.io docker-compose-v2
   sudo systemctl enable --now docker
   sudo usermod -aG docker "$USER"
   exit   # 重新 SSH 登录生效
   ```

4. 每台拉取课程基础镜像并打标签：

   ```bash
   docker pull ccr.ccs.tencentyun.com/ccnu-cloudcomputing/trpc-cpp-dev:2026.09
   docker tag ccr.ccs.tencentyun.com/ccnu-cloudcomputing/trpc-cpp-dev:2026.09 course/trpc-cpp-dev:2026.09
   ```

5. 每台把代码同步到 `~/lab1-mini-dht`（方式见 §2.1；单人部署推荐方式 A）。
6. 每台构建一次应用镜像（三台共用同一个 `lab1-ride-microservices:local`；只跑 DHT 节点的 B、C 也需要，否则启动时会去 Registry 拉不存在的镜像）：

   ```bash
   cd ~/lab1-mini-dht/docker
   docker compose build pricing
   ```

### 2.1 把代码送到三台机器

本仓库在本地是**普通目录，不是 git 仓库、也没有远端**，所以 `git clone <REPO-URL>` 不能直接用。按下面的方式选一种，效果等价于"每台机器上有一份 `~/lab1-mini-dht`"。

> 下文命令里的登录用户统一写 `ubuntu`（腾讯云 Ubuntu 镜像的默认用户）。若你创建实例时用的是 root 登录或自定义用户，把 `ubuntu@` 换成实际用户名即可。本机还没有 SSH 密钥时先执行 `ssh-keygen -t ed25519 -N ""`，直接回车用默认路径。

**方式 A：打包 + scp（单人部署推荐，无需任何账号）**

在你自己的电脑上（仓库根目录，Windows 用 Git Bash）：

```bash
cd "D:/c language/lab1-mini-dht"
bash scripts/pack-repo.sh          # 产出 dist/lab1-mini-dht-src.tar.gz，约 36 KB
```

`pack-repo.sh` 会排除 `dist/`（180 MB 的离线镜像包）、`build/`、`.workbuddy/`、`config/runtime/`、`data/evidence/`，只打包源码、配置、脚本和文档。若 CVM 拉不到课程镜像、需要走离线镜像包，改用 `bash scripts/pack-repo.sh --with-dist`（产出 `dist/lab1-mini-dht-with-dist.tar.gz`，约 180 MB）。

然后把包分别送到三台机器并解压（三行 `scp` 各执行一次）：

```bash
for H in <MACHINE-A-IP> <MACHINE-B-IP> <MACHINE-C-IP>; do
  scp dist/lab1-mini-dht-src.tar.gz ubuntu@$H:/tmp/
  ssh ubuntu@$H 'mkdir -p ~/lab1-mini-dht && tar -xzf /tmp/lab1-mini-dht-src.tar.gz -C ~/lab1-mini-dht'
done
```

没有配免密登录时，这个循环会让你输 6 次密码（每台 scp、ssh 各一次）。先配一次公钥可以省掉：

```bash
# macOS / Linux / Git Bash（带 ssh-copy-id 的环境）
for H in <MACHINE-A-IP> <MACHINE-B-IP> <MACHINE-C-IP>; do
  ssh-copy-id ubuntu@$H
done
```

Windows 上 Git Bash 通常不带 `ssh-copy-id`，先确认本机有公钥（`ls ~/.ssh/*.pub`，没有就 `ssh-keygen -t ed25519 -N ""`），再逐台追加：

```bash
for H in <MACHINE-A-IP> <MACHINE-B-IP> <MACHINE-C-IP>; do
  cat ~/.ssh/id_ed25519.pub | ssh ubuntu@$H 'mkdir -p ~/.ssh && chmod 700 ~/.ssh && cat >> ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys'
done
```

> 密码登录时 `ssh-copy-id` 会提示输入密码，输一次即可；`ubuntu` 账号在腾讯云镜像里默认允许密码登录。

解压后在任意一台上确认：

```bash
ls ~/lab1-mini-dht          # 应看到 CMakeLists.txt src/ proto/ scripts/ docker/ ...
```

**方式 B：走 git 远端（多机协作、需要反复改动时）**

在你自己的电脑上先建仓库并推到任意托管平台（Gitee / CNB / GitHub 私有库均可），然后三台机器 `git clone`：

```bash
cd "D:/c language/lab1-mini-dht"
git init
git add .
git commit -m "lab1b: three-node DHT"
git remote add origin <YOUR-REPO-URL>
git push -u origin main
```

三台机器上：

```bash
git clone <YOUR-REPO-URL> ~/lab1-mini-dht
```

注意：仓库根目录的 `.gitignore` 已经排除 `dist/`，否则那个 180 MB 的基础镜像包会让 push 被平台拒绝（GitHub 单文件上限 100 MB）。克隆后再 `git pull` 更新即可，这是方式 B 相对方式 A 的唯一优势。

**方式 C：先传一台，再机内分发**

如果你的电脑到 B、C 的 SSH 不通（例如只放行了 A 的 IP），可以先按方式 A 传到机器 A，再用 A 作为跳板：

```bash
# 在机器 A 上执行；需要 A 能 SSH 到 B、C（先 ssh-keygen + ssh-copy-id 一次）
scp /tmp/lab1-mini-dht-src.tar.gz ubuntu@<MACHINE-B-IP>:/tmp/
scp /tmp/lab1-mini-dht-src.tar.gz ubuntu@<MACHINE-C-IP>:/tmp/
```

## 3. 配置与启动脚本（任务 3）

- `config/dht-node.yaml.template`：DHT 节点配置模板，占位符 `__NODE_ID__`、`__SUCCESSOR_ADDR__`。
- `scripts/dht-gen-config.sh`：由模板生成 `config/runtime/dht-node-{a,b,c}.yaml`。导出 `NODE_A_IP`/`NODE_B_IP`/`NODE_C_IP` 时写入真实互通地址；未导出时默认用 Compose 服务名（单机模式）。
- `scripts/dht-up-node.sh a|b|c`：**每台机器只启动自己的节点**（机器 A 额外启动 pricing 与 trip）。
- `scripts/dht-up.sh`：单机全链路（三个节点 + pricing + trip），用于上云前自测。
- 节点自身存储在进程内 `std::unordered_map`，重启即清空；教学语义与 1A 内存表一致，持久化不在本实验范围。

## 4. trip-service 的 DHT 集成（任务 4、5、6）

| 文件 | 内容 |
|---|---|
| `proto/dht.proto` | `DhtService`：`Put(key, value)`、`Get(key)`、`RingInfo()`，全部节点监听 19001 |
| `src/dht_ring.h` | SHA-256 一致哈希环：位置、owner 查找、前驱/后继 |
| `src/dht_node.cc` | DHT 节点服务端（`dht_server`）：本地存储 + 后继转发 + 环信息 |
| `src/dht_client.h` | DHT 客户端封装，trip-service 只连入口 `trpc.dht.DhtService`（node-a） |
| `src/trip_service.{h,cc}` | 内存表替换为 DHT（见下） |
| `config/trip-service.yaml` | 新增客户端条目 `trpc.dht.DhtService → dht-node-a:19001` |

CreateRide / GetTrip 中的关键代码（`src/trip_service.cc`）：

```cpp
// CreateRide（拿到报价、构造 Trip 之后）：
const std::string dht_key = "trip:" + trip.trip_id();
dht_client_->Put(context, dht_key, trip.SerializeAsString(), &dht_owner, &dht_error);

// GetTrip：
dht_client_->Get(context, "trip:" + request->trip_id(),
                 &value, &found, &dht_owner, &dht_error);
// found 时：trip.ParseFromString(value)
```

Proto 契约（`CreateRide`/`GetTrip`）与 1A 完全一致，ride-client 与 pricing-service 无感。

## 5. 三台机器部署步骤（任务 7）

**第 0 步：先把三个互通地址填进表**（下表同时用于安全和后续占位符替换）：

| 机器 | 角色 | 互通地址（内网优先） |
|---|---|---|
| A | node-a + pricing + trip | `<MACHINE-A-IP>` |
| B | node-b | `<MACHINE-B-IP>` |
| C | node-c | `<MACHINE-C-IP>` |

**第 1 步：三台各自 export 变量并启动本机服务**（脚本缺变量会直接报错退出，避免把 Compose 服务名当成跨机地址）：

```bash
export NODE_A_IP=<MACHINE-A-IP> NODE_B_IP=<MACHINE-B-IP> NODE_C_IP=<MACHINE-C-IP>

# 机器 <MACHINE-A-IP>：节点 A + pricing + trip（trip 固定以 node-a 为 DHT 入口）
bash scripts/dht-up-node.sh a

# 机器 <MACHINE-B-IP>：只启动节点 B
bash scripts/dht-up-node.sh b

# 机器 <MACHINE-C-IP>：只启动节点 C
bash scripts/dht-up-node.sh c
```

每台启动后脚本会打印本机生成的 `target: <后继地址>:19001`，A 应为 B 的地址、B 应为 C 的地址、C 应为 A 的地址；不是的话说明变量没传对。

**第 2 步：确认连通性**（在机器 A 上执行，三行都应有响应）：

```bash
docker compose exec -T dht-node-a bash -lc 'for h in <MACHINE-B-IP> <MACHINE-C-IP>; do timeout 3 bash -c "echo > /dev/tcp/$h/19001" && echo "$h:19001 OK" || echo "$h:19001 FAIL"; done'
```

然后在机器 A 上验证（`client.sh` 已在镜像内，通过映射端口访问 trip）：

```bash
bash scripts/dht-verify.sh
```

11 项 PASS 且三笔订单分别由 node-b / node-a / node-c 存储，即三节点环工作正常。

## 6. 证据收集（任务 8）

任一机器（本机即可）运行：

```bash
export NODE_A_SSH=ubuntu@<MACHINE-A-IP>
export NODE_B_SSH=ubuntu@<MACHINE-B-IP>
export NODE_C_SSH=ubuntu@<MACHINE-C-IP>
export REMOTE_DIR=~/lab1-mini-dht
bash scripts/dht-collect-evidence.sh
```

输出到 `data/evidence/lab1b/node-{a,b,c}/`，每台包含：`hostname.txt`（主机名）、`compose-ps.txt`（docker compose ps）、`dht-node-config.yaml`（生效节点配置）、`dht-node-log.txt`（含 `put/get key=... owner=...` 的节点日志）；机器 A 另存 `trip-pricing-log.txt`（订单日志）。写入报告后再运行 `bash scripts/collect-result.sh` 打包。

## 7. 复现命令汇总：从空白 CVM 到三节点运行（任务 9）

```bash
# ===== 控制台（安全组）：三台互相放行 TCP 19001，另放行 22 =====

# ===== 在本地电脑上（先把代码打包，详见 §2.1 方式 A）=====
cd "D:/c language/lab1-mini-dht" && bash scripts/pack-repo.sh
for H in <MACHINE-A-IP> <MACHINE-B-IP> <MACHINE-C-IP>; do
  scp dist/lab1-mini-dht-src.tar.gz ubuntu@$H:/tmp/
  ssh ubuntu@$H 'mkdir -p ~/lab1-mini-dht && tar -xzf /tmp/lab1-mini-dht-src.tar.gz -C ~/lab1-mini-dht'
done

# ===== 在每台 CVM 上（0. 环境准备，三台相同）=====
ssh ubuntu@<MACHINE-X-IP>
sudo apt update && sudo apt install -y docker.io docker-compose-v2
sudo systemctl enable --now docker && sudo usermod -aG docker "$USER"
exit
ssh ubuntu@<MACHINE-X-IP>
docker pull ccr.ccs.tencentyun.com/ccnu-cloudcomputing/trpc-cpp-dev:2026.09
docker tag ccr.ccs.tencentyun.com/ccnu-cloudcomputing/trpc-cpp-dev:2026.09 course/trpc-cpp-dev:2026.09
cd ~/lab1-mini-dht/docker && docker compose build pricing && cd ..

# ===== 每台 CVM 上（1. 注入三台互通地址并启动自己的服务）=====
cd ~/lab1-mini-dht
export NODE_A_IP=<MACHINE-A-IP> NODE_B_IP=<MACHINE-B-IP> NODE_C_IP=<MACHINE-C-IP>
# 机器 A：
bash scripts/dht-up-node.sh a
# 机器 B：
bash scripts/dht-up-node.sh b
# 机器 C：
bash scripts/dht-up-node.sh c

# ===== 在机器 A 上（2. 验证与取证）=====
bash scripts/dht-verify.sh
export NODE_A_SSH=ubuntu@<MACHINE-A-IP> NODE_B_SSH=ubuntu@<MACHINE-B-IP> \
       NODE_C_SSH=ubuntu@<MACHINE-C-IP> REMOTE_DIR=~/lab1-mini-dht
bash scripts/dht-collect-evidence.sh
```

> 单机自测（无三台 CVM 时）：仓库根目录直接 `bash scripts/dht-up.sh && bash scripts/dht-verify.sh`，三个节点以 Compose 服务名互通。

## 8. 单人任务清单对照

| 甲方任务 | 交付物 |
|---|---|
| 1. node_id/端口/地址 + 环图 | 本文 §1；`src/dht_ring.h`（算法与文档一致） |
| 2. CVM、Docker、基础镜像 | 本文 §2（照 README §2 执行即可） |
| 3. 配置模板 + 每机只启动自己的节点 | `config/dht-node.yaml.template`、`scripts/dht-gen-config.sh`、`scripts/dht-up-node.sh` |
| 4. DHT 客户端连接 node-a | `src/dht_client.h`、`config/trip-service.yaml` |
| 5. CreateRide → Put | `src/trip_service.cc` |
| 6. GetTrip → Get + ParseFromString | `src/trip_service.cc` |
| 7. 启动 node-a/pricing/trip，node-a 入口 | 本文 §5；`scripts/dht-up-node.sh` |
| 8. 保存三机证据 | `scripts/dht-collect-evidence.sh` |
| 9. 复现命令（占位符） | 本文 §7 |
