#pragma once

#include "proto/pricing.trpc.pb.h"

namespace lab1 {

// Pricing is the single owner of the fare policy. Quotes are computed
// deterministically from the offline formula below; no real map, ride-hailing
// or payment API is called.
class PricingServiceImpl final : public ::trpc::ride::PricingService {
 public:
  PricingServiceImpl() = default;

  ::trpc::Status EstimateFare(::trpc::ServerContextPtr context,
                              const ::trpc::ride::EstimateFareRequest* request,
                              ::trpc::ride::EstimateFareReply* reply) override;
};

}  // namespace lab1
