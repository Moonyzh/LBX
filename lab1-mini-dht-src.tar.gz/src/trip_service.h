#pragma once

#include <cstdint>
#include <memory>
#include <mutex>
#include <string>

#include "proto/pricing.trpc.pb.h"
#include "proto/trip.trpc.pb.h"
#include "src/dht_client.h"

namespace lab1 {

// Trip owns an order's lifecycle. In lab 1A the order table was an in-memory
// unordered_map. In lab 1B the same CreateRide/GetTrip signatures persist
// orders into a three-node DHT instead:
//   CreateRide: Trip.SerializeAsString() -> Put("trip:" + trip_id, bytes)
//   GetTrip:    Get("trip:" + trip_id)   -> Trip.ParseFromString(value)
// trip-service only ever contacts the DHT entry node (node-a); the ring
// routes each key to its owner.
class TripServiceImpl final : public ::trpc::ride::TripService {
 public:
  TripServiceImpl();

  ::trpc::Status CreateRide(::trpc::ServerContextPtr context,
                            const ::trpc::ride::CreateRideRequest* request,
                            ::trpc::ride::CreateRideReply* reply) override;
  ::trpc::Status GetTrip(::trpc::ServerContextPtr context,
                         const ::trpc::ride::GetTripRequest* request,
                         ::trpc::ride::GetTripReply* reply) override;

 private:
  std::string NextTripId();

  std::shared_ptr<::trpc::ride::PricingServiceServiceProxy> pricing_proxy_;
  std::unique_ptr<DhtClient> dht_client_;
  std::uint64_t next_trip_number_{1};
  std::mutex trip_number_mutex_;
};

}  // namespace lab1
