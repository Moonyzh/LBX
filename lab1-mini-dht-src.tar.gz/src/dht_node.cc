// One DHT ring node (lab 1B). Each machine runs exactly one of these:
//   dht_server --config=... --node_id=node-a --ring_nodes=node-a,node-b,node-c
// The node stores keys it owns and forwards other keys to its clockwise
// successor, so only the successor's address is needed in the YAML config.

#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>
#include <utility>

#include "fmt/format.h"
#include "gflags/gflags.h"
#include "trpc/client/make_client_context.h"
#include "trpc/client/trpc_client.h"
#include "trpc/common/status.h"
#include "trpc/common/trpc_app.h"
#include "trpc/log/trpc_log.h"

#include "proto/dht.trpc.pb.h"
#include "src/dht_ring.h"

DEFINE_string(node_id, "", "this node's id on the DHT ring, e.g. node-a");
DEFINE_string(ring_nodes, "", "comma separated ring membership, e.g. node-a,node-b,node-c");

namespace lab1 {

class DhtNodeServiceImpl final : public ::trpc::dht::DhtService {
 public:
  bool Init(const std::string& node_id, const std::string& ring_nodes) {
    node_id_ = node_id;
    if (!ring_.LoadFromIds(ring_nodes)) {
      TRPC_FMT_ERROR("invalid --ring_nodes='{}'", ring_nodes);
      return false;
    }
    if (!ring_.Contains(node_id_)) {
      TRPC_FMT_ERROR("--node_id={} is not part of --ring_nodes='{}'", node_id_, ring_nodes);
      return false;
    }
    // The successor's address lives in the client config under this name
    // (see config/dht-node.yaml.template). No other peer address is needed.
    successor_proxy_ =
        ::trpc::GetTrpcClient()->GetProxy<::trpc::dht::DhtServiceServiceProxy>("trpc.dht.successor");
    TRPC_FMT_INFO("dht node={} position={:x} successor={} predecessor={} ring_size={}", node_id_,
                  ring_.PositionOf(node_id_), ring_.SuccessorOf(node_id_), ring_.PredecessorOf(node_id_),
                  ring_.size());
    return true;
  }

  ::trpc::Status Put(::trpc::ServerContextPtr context, const ::trpc::dht::PutRequest* request,
                     ::trpc::dht::PutReply* reply) override {
    const std::string owner = ring_.FindOwner(request->key());
    if (owner == node_id_) {
      {
        std::lock_guard<std::mutex> lock(store_mutex_);
        store_[request->key()] = request->value();
      }
      reply->set_ok(true);
      reply->set_owner(node_id_);
      reply->set_hops(request->hops());
      reply->set_message("stored on " + node_id_);
      TRPC_FMT_INFO("put key={} owner={} hops={} (stored locally)", request->key(), owner, request->hops());
      return ::trpc::kSuccStatus;
    }

    // Safety net against a misconfigured successor chain.
    if (request->hops() + 1 > ring_.size()) {
      reply->set_ok(false);
      reply->set_message("put key=" + request->key() + " exceeded ring size hops; check successor configs");
      TRPC_FMT_ERROR("put key={} owner={} hops={} routing loop detected", request->key(), owner,
                     request->hops());
      return ::trpc::kSuccStatus;
    }

    ::trpc::dht::PutRequest forwarded(*request);
    forwarded.set_hops(request->hops() + 1);
    const auto client_context = ::trpc::MakeClientContext(context, successor_proxy_);
    const ::trpc::Status status = successor_proxy_->Put(client_context, forwarded, reply);
    if (!status.OK()) {
      reply->set_ok(false);
      reply->set_message("forward to successor " + ring_.SuccessorOf(node_id_) +
                         " failed: " + status.ErrorMessage());
      TRPC_FMT_WARN("put key={} owner={} forward to successor={} failed: {}", request->key(), owner,
                    ring_.SuccessorOf(node_id_), status.ErrorMessage());
    } else {
      TRPC_FMT_INFO("put key={} owner={} forwarded to successor={} hops={}", request->key(), owner,
                    ring_.SuccessorOf(node_id_), reply->hops());
    }
    return ::trpc::kSuccStatus;
  }

  ::trpc::Status Get(::trpc::ServerContextPtr context, const ::trpc::dht::GetRequest* request,
                     ::trpc::dht::GetReply* reply) override {
    const std::string owner = ring_.FindOwner(request->key());
    if (owner == node_id_) {
      std::string value;
      {
        std::lock_guard<std::mutex> lock(store_mutex_);
        const auto it = store_.find(request->key());
        if (it != store_.end()) value = it->second;
      }
      reply->set_ok(true);
      reply->set_found(!value.empty());
      reply->set_value(value);
      reply->set_owner(node_id_);
      reply->set_hops(request->hops());
      reply->set_message(value.empty() ? "key not found on " + node_id_ : "read from " + node_id_);
      TRPC_FMT_INFO("get key={} owner={} hops={} found={} (local read)", request->key(), owner,
                    request->hops(), !value.empty());
      return ::trpc::kSuccStatus;
    }

    if (request->hops() + 1 > ring_.size()) {
      reply->set_ok(false);
      reply->set_message("get key=" + request->key() + " exceeded ring size hops; check successor configs");
      TRPC_FMT_ERROR("get key={} owner={} hops={} routing loop detected", request->key(), owner,
                     request->hops());
      return ::trpc::kSuccStatus;
    }

    ::trpc::dht::GetRequest forwarded(*request);
    forwarded.set_hops(request->hops() + 1);
    const auto client_context = ::trpc::MakeClientContext(context, successor_proxy_);
    const ::trpc::Status status = successor_proxy_->Get(client_context, forwarded, reply);
    if (!status.OK()) {
      reply->set_ok(false);
      reply->set_message("forward to successor " + ring_.SuccessorOf(node_id_) +
                         " failed: " + status.ErrorMessage());
      TRPC_FMT_WARN("get key={} owner={} forward to successor={} failed: {}", request->key(), owner,
                    ring_.SuccessorOf(node_id_), status.ErrorMessage());
    } else {
      TRPC_FMT_INFO("get key={} owner={} forwarded to successor={} hops={}", request->key(), owner,
                    ring_.SuccessorOf(node_id_), reply->hops());
    }
    return ::trpc::kSuccStatus;
  }

  ::trpc::Status RingInfo(::trpc::ServerContextPtr context, const ::trpc::dht::RingInfoRequest* request,
                          ::trpc::dht::RingInfoReply* reply) override {
    for (const auto& id : ring_.ids()) {
      auto* node = reply->add_nodes();
      node->set_node_id(id);
      node->set_position(ring_.PositionOf(id));
      node->set_successor(ring_.SuccessorOf(id));
      node->set_predecessor(ring_.PredecessorOf(id));
      node->set_self(id == node_id_);
    }
    reply->set_message("ring info from " + node_id_);
    TRPC_FMT_INFO("ring info served by {}", node_id_);
    return ::trpc::kSuccStatus;
  }

 private:
  std::string node_id_;
  dht::Ring ring_;
  std::shared_ptr<::trpc::dht::DhtServiceServiceProxy> successor_proxy_;
  std::unordered_map<std::string, std::string> store_;
  std::mutex store_mutex_;
};

class DhtNodeServer final : public ::trpc::TrpcApp {
 public:
  int Initialize() override {
    if (FLAGS_node_id.empty() || FLAGS_ring_nodes.empty()) {
      TRPC_FMT_ERROR("both --node_id and --ring_nodes are required, e.g. "
                     "--node_id=node-a --ring_nodes=node-a,node-b,node-c");
      return -1;
    }
    auto impl = std::make_shared<DhtNodeServiceImpl>();
    if (!impl->Init(FLAGS_node_id, FLAGS_ring_nodes)) return -1;
    RegisterService("trpc.dht.DhtService", impl);
    return 0;
  }
  void Destroy() override {}
};

}  // namespace lab1

int main(int argc, char** argv) {
  // Extract the lab-specific flags first; the framework then parses --config.
  google::ParseCommandLineFlags(&argc, &argv, true);
  lab1::DhtNodeServer server;
  server.Main(argc, argv);
  server.Wait();
  return 0;
}
