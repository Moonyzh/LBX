#include "src/trip_service.h"

#include <iomanip>
#include <sstream>
#include <utility>

#include "trpc/client/make_client_context.h"
#include "trpc/client/trpc_client.h"
#include "trpc/common/status.h"
#include "trpc/log/trpc_log.h"

namespace lab1 {

TripServiceImpl::TripServiceImpl() {
  pricing_proxy_ = ::trpc::GetTrpcClient()->GetProxy<::trpc::ride::PricingServiceServiceProxy>(
      "trpc.ride.pricing.PricingService");
  // DHT entry point: node-a only (target configured in trip-service.yaml).
  dht_client_ = std::make_unique<DhtClient>("trpc.dht.DhtService");
}

std::string TripServiceImpl::NextTripId() {
  std::lock_guard<std::mutex> lock(trip_number_mutex_);
  std::ostringstream stream;
  stream << "trip-" << std::setfill('0') << std::setw(6) << next_trip_number_++;
  return stream.str();
}

::trpc::Status TripServiceImpl::CreateRide(
    ::trpc::ServerContextPtr context, const ::trpc::ride::CreateRideRequest* request,
    ::trpc::ride::CreateRideReply* reply) {
  if (request->passenger_id().empty() || request->origin().empty() || request->destination().empty() ||
      request->distance_km() <= 0.0) {
    reply->set_ok(false);
    reply->set_message("passenger, origin, destination and a positive distance are required");
    return ::trpc::kSuccStatus;
  }

  // trip-service must call the pricing service through tRPC and never copy
  // the fare formula: pricing-service is the single owner of that policy.
  ::trpc::ride::EstimateFareRequest pricing_request;
  pricing_request.set_city(request->city());
  pricing_request.set_distance_km(request->distance_km());
  pricing_request.set_time_slot(request->time_slot());
  ::trpc::ride::EstimateFareReply pricing_reply;
  const auto pricing_context = ::trpc::MakeClientContext(context, pricing_proxy_);
  const ::trpc::Status pricing_status =
      pricing_proxy_->EstimateFare(pricing_context, pricing_request, &pricing_reply);
  if (!pricing_status.OK() || !pricing_reply.ok()) {
    reply->set_ok(false);
    reply->set_message(pricing_status.OK() ? pricing_reply.message()
                                           : "pricing-service RPC failed: " + pricing_status.ErrorMessage());
    TRPC_FMT_WARN("create ride passenger_id={} downstream=pricing-service result={}",
                  request->passenger_id(), reply->message());
    return ::trpc::kSuccStatus;
  }

  ::trpc::ride::Trip trip;
  trip.set_trip_id(NextTripId());
  trip.set_passenger_id(request->passenger_id());
  trip.set_city(request->city());
  trip.set_origin(request->origin());
  trip.set_destination(request->destination());
  trip.set_distance_km(request->distance_km());
  trip.set_time_slot(request->time_slot());
  trip.set_estimated_fare(pricing_reply.total_fare());
  trip.set_status("WAITING");

  // Lab 1B: persist the order into the DHT instead of an in-memory map.
  // Trip.SerializeAsString() -> Put("trip:" + trip_id, bytes). The entry
  // node routes the key to its owner; the owner id is kept for evidence.
  const std::string dht_key = "trip:" + trip.trip_id();
  std::string dht_owner;
  std::string dht_error;
  if (!dht_client_->Put(context, dht_key, trip.SerializeAsString(), &dht_owner, &dht_error)) {
    reply->set_ok(false);
    reply->set_message(dht_error);
    TRPC_FMT_WARN("create ride trip_id={} dht put failed: {}", trip.trip_id(), dht_error);
    return ::trpc::kSuccStatus;
  }

  *reply->mutable_trip() = trip;
  reply->set_ok(true);
  reply->set_message("trip stored in dht");
  TRPC_FMT_INFO("trip_id={} passenger_id={} downstream=pricing-service estimated_fare={} dht_key={} "
                "dht_owner={}",
                trip.trip_id(), trip.passenger_id(), trip.estimated_fare(), dht_key, dht_owner);
  return ::trpc::kSuccStatus;
}

::trpc::Status TripServiceImpl::GetTrip(::trpc::ServerContextPtr context,
                                         const ::trpc::ride::GetTripRequest* request,
                                         ::trpc::ride::GetTripReply* reply) {
  // Lab 1B: Get("trip:" + trip_id) -> Trip.ParseFromString(value).
  const std::string dht_key = "trip:" + request->trip_id();
  std::string value;
  bool found = false;
  std::string dht_owner;
  std::string dht_error;
  if (!dht_client_->Get(context, dht_key, &value, &found, &dht_owner, &dht_error)) {
    reply->set_found(false);
    reply->set_message(dht_error);
    TRPC_FMT_WARN("get trip_id={} dht get failed: {}", request->trip_id(), dht_error);
    return ::trpc::kSuccStatus;
  }

  reply->set_found(found);
  if (found) {
    ::trpc::ride::Trip trip;
    if (!trip.ParseFromString(value)) {
      reply->set_found(false);
      reply->set_message("stored trip bytes cannot be parsed");
      TRPC_FMT_ERROR("get trip_id={} stored bytes cannot be parsed", request->trip_id());
      return ::trpc::kSuccStatus;
    }
    *reply->mutable_trip() = trip;
    reply->set_message("trip read from dht owner=" + dht_owner);
  } else {
    reply->set_message("trip not found in dht");
  }
  TRPC_FMT_INFO("trip_id={} found={} dht_owner={}", request->trip_id(), reply->found(), dht_owner);
  return ::trpc::kSuccStatus;
}

}  // namespace lab1
