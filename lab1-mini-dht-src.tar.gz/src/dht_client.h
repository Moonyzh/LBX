#pragma once

#include <memory>
#include <string>

#include "trpc/client/make_client_context.h"
#include "trpc/client/trpc_client.h"
#include "trpc/common/status.h"
#include "trpc/log/trpc_log.h"

#include "proto/dht.trpc.pb.h"

namespace lab1 {

// Client side of the mini DHT. trip-service only ever talks to the entry node
// (node-a, target dht-node-a:19001 in trip-service.yaml); the ring itself
// routes every key to its owning node. This is the layer that replaces the
// 1A in-memory map without changing CreateRide/GetTrip signatures.
class DhtClient final {
 public:
  explicit DhtClient(const std::string& entry_service_name = "trpc.dht.DhtService") {
    proxy_ = ::trpc::GetTrpcClient()->GetProxy<::trpc::dht::DhtServiceServiceProxy>(entry_service_name);
  }

  // Returns true when the key/value is stored somewhere on the ring;
  // *owner receives the storing node id (log/report evidence).
  bool Put(const ::trpc::ServerContextPtr& context, const std::string& key, const std::string& value,
           std::string* owner, std::string* error) {
    ::trpc::dht::PutRequest request;
    request.set_key(key);
    request.set_value(value);
    ::trpc::dht::PutReply reply;
    const auto client_context = ::trpc::MakeClientContext(context, proxy_);
    const ::trpc::Status status = proxy_->Put(client_context, request, &reply);
    if (!status.OK()) {
      *error = "dht put rpc failed: " + status.ErrorMessage();
      TRPC_FMT_WARN("dht put key={} error={}", key, *error);
      return false;
    }
    if (!reply.ok()) {
      *error = "dht put rejected: " + reply.message();
      TRPC_FMT_WARN("dht put key={} error={}", key, *error);
      return false;
    }
    *owner = reply.owner();
    TRPC_FMT_INFO("dht put key={} owner={} hops={}", key, reply.owner(), reply.hops());
    return true;
  }

  // Returns true when the RPC itself succeeded; *found says whether the key
  // exists, *value then holds the stored bytes and *owner the reading node.
  bool Get(const ::trpc::ServerContextPtr& context, const std::string& key, std::string* value, bool* found,
           std::string* owner, std::string* error) {
    ::trpc::dht::GetRequest request;
    request.set_key(key);
    ::trpc::dht::GetReply reply;
    const auto client_context = ::trpc::MakeClientContext(context, proxy_);
    const ::trpc::Status status = proxy_->Get(client_context, request, &reply);
    if (!status.OK()) {
      *error = "dht get rpc failed: " + status.ErrorMessage();
      *found = false;
      TRPC_FMT_WARN("dht get key={} error={}", key, *error);
      return false;
    }
    if (!reply.ok()) {
      *error = "dht get rejected: " + reply.message();
      *found = false;
      TRPC_FMT_WARN("dht get key={} error={}", key, *error);
      return false;
    }
    *found = reply.found();
    *value = reply.value();
    *owner = reply.owner();
    TRPC_FMT_INFO("dht get key={} owner={} found={} hops={}", key, reply.owner(), reply.found(),
                  reply.hops());
    return true;
  }

 private:
  std::shared_ptr<::trpc::dht::DhtServiceServiceProxy> proxy_;
};

}  // namespace lab1
