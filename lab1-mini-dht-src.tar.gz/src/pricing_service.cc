#include "src/pricing_service.h"

#include "trpc/log/trpc_log.h"

namespace lab1 {

namespace {
// Fare policy: pricing-service is the single owner of these numbers.
constexpr double kBaseFare = 10.0;
constexpr double kFarePerKm = 2.4;
constexpr double kPeakMultiplier = 1.35;
constexpr double kOffPeakMultiplier = 1.0;
}  // namespace

// TODO(Lab1A-1): deterministic offline pricing.
//   base_fare     = 10.0
//   distance_fare = distance_km * 2.4
//   multiplier    = peak ? 1.35 : 1.0
//   total_fare    = (base_fare + distance_fare) * multiplier
::trpc::Status PricingServiceImpl::EstimateFare(
    ::trpc::ServerContextPtr context, const ::trpc::ride::EstimateFareRequest* request,
    ::trpc::ride::EstimateFareReply* reply) {
  if (request->city().empty()) {
    reply->set_ok(false);
    reply->set_message("city is required");
    TRPC_FMT_WARN("reject quote reason=empty_city");
    return ::trpc::kSuccStatus;
  }
  if (request->distance_km() <= 0.0) {
    reply->set_ok(false);
    reply->set_message("distance_km must be positive");
    TRPC_FMT_WARN("reject quote city={} reason=bad_distance distance_km={}", request->city(),
                  request->distance_km());
    return ::trpc::kSuccStatus;
  }
  if (request->time_slot() != "peak" && request->time_slot() != "offpeak") {
    reply->set_ok(false);
    reply->set_message("time_slot must be peak or offpeak");
    TRPC_FMT_WARN("reject quote city={} reason=bad_time_slot time_slot={}", request->city(),
                  request->time_slot());
    return ::trpc::kSuccStatus;
  }

  const double base_fare = kBaseFare;
  const double distance_fare = request->distance_km() * kFarePerKm;
  const double multiplier =
      request->time_slot() == "peak" ? kPeakMultiplier : kOffPeakMultiplier;
  const double total_fare = (base_fare + distance_fare) * multiplier;

  reply->set_ok(true);
  reply->set_base_fare(base_fare);
  reply->set_distance_fare(distance_fare);
  reply->set_multiplier(multiplier);
  reply->set_total_fare(total_fare);
  reply->set_message("offline deterministic quote");
  TRPC_FMT_INFO("quote city={} distance_km={} time_slot={} total_fare={:.2f}", request->city(),
                request->distance_km(), request->time_slot(), total_fare);
  return ::trpc::kSuccStatus;
}

}  // namespace lab1
