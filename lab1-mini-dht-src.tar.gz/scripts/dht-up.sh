#!/usr/bin/env bash
# Single-machine lab 1B stack: three DHT ring nodes + pricing + trip.
# Every ride goes through node-a as the DHT entry point (trip-service.yaml).
# For the three-CVM deployment use scripts/dht-up-node.sh on each machine.
set -euo pipefail
cd "$(dirname "$0")/.."
bash scripts/dht-gen-config.sh
cd docker
docker compose up --build --force-recreate -d dht-node-a dht-node-b dht-node-c pricing trip
docker compose ps
