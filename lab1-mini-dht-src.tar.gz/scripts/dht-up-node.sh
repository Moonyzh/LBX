#!/usr/bin/env bash
# Start ONLY the services this machine owns (three-CVM deployment):
#   machine A: bash scripts/dht-up-node.sh a   -> dht-node-a + pricing + trip
#   machine B: bash scripts/dht-up-node.sh b   -> dht-node-b only
#   machine C: bash scripts/dht-up-node.sh c   -> dht-node-c only
#
# Required on every machine before running (reachable addresses of the three
# CVMs, private IP when they share a VPC, otherwise public IP):
#   export NODE_A_IP=<MACHINE-A-IP> NODE_B_IP=<MACHINE-B-IP> NODE_C_IP=<MACHINE-C-IP>
# All three must be set: a node whose successor target falls back to a Compose
# service name cannot reach its peer across machines.
set -euo pipefail
if [[ $# -ne 1 ]] || [[ ! " a b c " =~ " $1 " ]]; then
  echo "usage: bash scripts/dht-up-node.sh a|b|c" >&2
  exit 2
fi
node="$1"

missing=""
for name in NODE_A_IP NODE_B_IP NODE_C_IP; do
  [[ -z "${!name:-}" ]] && missing="${missing} ${name}"
done
if [[ -n "$missing" ]]; then
  echo "ERROR: missing environment variable(s):${missing}" >&2
  echo "       export NODE_A_IP=<MACHINE-A-IP> NODE_B_IP=<MACHINE-B-IP> NODE_C_IP=<MACHINE-C-IP>" >&2
  echo "       (also allow inbound TCP 19001 between the three CVMs)" >&2
  exit 2
fi

cd "$(dirname "$0")/.."
bash scripts/dht-gen-config.sh

cd docker
# Every machine needs the application image locally, even when it runs only a
# DHT node: build the shared image once from the pricing service definition
# (all services use lab1-ride-microservices:local).
docker compose build pricing

services="dht-node-${node}"
if [[ "$node" == "a" ]]; then
  # Machine A also hosts pricing-service and trip-service; trip uses
  # node-a on the same machine as its DHT entry point.
  services="dht-node-a pricing trip"
fi
docker compose up --force-recreate -d $services
docker compose ps
echo
echo "successor target in this machine's node config:"
grep -n "target:" "../config/runtime/dht-node-${node}.yaml" || true
