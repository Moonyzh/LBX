#!/usr/bin/env bash
# Verify the lab 1B chain: ride-client -> trip-service -> (pricing) -> DHT.
# Expected placement with the SHA-256 ring (positions of node-a/b/c):
#   trip-000001 -> node-b (1 hop from node-a)
#   trip-000002 -> node-a (stored locally at the entry node)
#   trip-000003 -> node-c (2 hops: node-a -> node-b -> node-c)
set -euo pipefail

ROOT="$(dirname "$0")"

assert_contains() {
  local text="$1"
  local expected="$2"
  local label="$3"
  if ! grep -Fq "$expected" <<<"$text"; then
    echo "ASSERTION FAILED: $label; expected [$expected]" >&2
    echo "actual output:" >&2
    echo "$text" >&2
    return 1
  fi
  echo "PASS: $label"
}

peak_create="$("$ROOT/client.sh" --op=create --passenger_id=alice --origin=campus --destination=railway-station --distance_km=8.5 --time_slot=peak)"
echo "$peak_create"
assert_contains "$peak_create" "create_ok=1" "peak CreateRide succeeds via DHT put"
assert_contains "$peak_create" "trip_id=trip-000001" "first trip has predictable ID"
assert_contains "$peak_create" "estimated_fare=41.04" "peak fare follows the teaching rule"
assert_contains "$peak_create" "status=WAITING" "new trip starts waiting"

peak_get="$("$ROOT/client.sh" --op=get --trip_id=trip-000001)"
echo "$peak_get"
assert_contains "$peak_get" "found=1" "first trip read back from DHT"
assert_contains "$peak_get" "estimated_fare=41.04" "queried peak fare is retained"

offpeak_create="$("$ROOT/client.sh" --op=create --passenger_id=alice --origin=library --destination=hospital --distance_km=3.0 --time_slot=offpeak)"
echo "$offpeak_create"
assert_contains "$offpeak_create" "create_ok=1" "offpeak CreateRide succeeds via DHT put"
assert_contains "$offpeak_create" "trip_id=trip-000002" "second trip has predictable ID"
assert_contains "$offpeak_create" "estimated_fare=17.20" "offpeak fare follows the teaching rule"

offpeak_get="$("$ROOT/client.sh" --op=get --trip_id=trip-000002)"
echo "$offpeak_get"
assert_contains "$offpeak_get" "found=1" "second trip read back from DHT"

# A third trip lands on the third node, proving the ring actually distributes.
third_create="$("$ROOT/client.sh" --op=create --passenger_id=bob --origin=airport --destination=hospital --distance_km=5.0 --time_slot=peak)"
echo "$third_create"
assert_contains "$third_create" "create_ok=1" "third CreateRide succeeds via DHT put"
assert_contains "$third_create" "trip_id=trip-000003" "third trip has predictable ID"
third_get="$("$ROOT/client.sh" --op=get --trip_id=trip-000003)"
echo "$third_get"
assert_contains "$third_get" "found=1" "third trip read back from DHT"

echo
echo "Ring placement evidence (put/get logs per node):"
cd "$(dirname "$0")/../docker"
docker compose logs --no-color dht-node-a dht-node-b dht-node-c 2>/dev/null \
  | grep -E "put key|get key" | tail -20 || true
