#!/usr/bin/env bash
set -euo pipefail

# This is the same deterministic check used by collect-result.sh. Teaching
# platforms can invoke it as the first-pass grader before a human reads logs
# and the service-boundary explanation in the report.
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
"$ROOT/scripts/up.sh"
"$ROOT/scripts/verify.sh"
"$ROOT/scripts/fault-test.sh"
echo "AUTOGRADER: PASS"
