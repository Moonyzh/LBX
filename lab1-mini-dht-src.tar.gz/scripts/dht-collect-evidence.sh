#!/usr/bin/env bash
# Task 8 evidence collection: from each of the three machines save hostname,
# docker compose ps, the generated node config and recent DHT/trip logs.
#
# Configure before running (keep real IPs out of committed files):
#   export NODE_A_SSH=ubuntu@<MACHINE-A-IP>
#   export NODE_B_SSH=ubuntu@<MACHINE-B-IP>
#   export NODE_C_SSH=ubuntu@<MACHINE-C-IP>
#   export REMOTE_DIR=/home/ubuntu/lab1-mini-dht   # repo path on each CVM
# Output lands in data/evidence/lab1b/node-{a,b,c}/ for the report package.
set -uo pipefail  # no -e: one unreachable machine must not block the others

ROOT="$(dirname "$0")/.."
OUT="$ROOT/data/evidence/lab1b"
REMOTE_DIR="${REMOTE_DIR:-~/lab1-mini-dht}"
mkdir -p "$OUT"

collect() {
  local name="$1" ssh_target="$2"
  local dir="$OUT/node-${name}"
  if [[ -z "$ssh_target" ]]; then
    echo "SKIP node-${name}: set NODE_${name^^}_SSH=ubuntu@<MACHINE-${name^^}-IP> to collect"
    return 0
  fi
  mkdir -p "$dir"
  echo "== node-${name} (${ssh_target}) =="
  ssh "$ssh_target" "hostname" >"$dir/hostname.txt" 2>&1 || echo "WARN: hostname failed"
  ssh "$ssh_target" "cd ${REMOTE_DIR}/docker && docker compose ps" >"$dir/compose-ps.txt" 2>&1 || echo "WARN: compose ps failed"
  ssh "$ssh_target" "cat ${REMOTE_DIR}/config/runtime/dht-node-${name}.yaml" \
    >"$dir/dht-node-config.yaml" 2>&1 || echo "WARN: node config failed"
  ssh "$ssh_target" "cd ${REMOTE_DIR}/docker && docker compose logs --no-color --tail 300 dht-node-${name}" \
    >"$dir/dht-node-log.txt" 2>&1 || echo "WARN: node log failed"
  if [[ "$name" == "a" ]]; then
    ssh "$ssh_target" "cd ${REMOTE_DIR}/docker && docker compose logs --no-color --tail 300 trip pricing" \
      >"$dir/trip-pricing-log.txt" 2>&1 || echo "WARN: trip/pricing log failed"
  fi
  echo "saved to $dir"
}

collect a "${NODE_A_SSH:-}"
collect b "${NODE_B_SSH:-}"
collect c "${NODE_C_SSH:-}"
echo
echo "evidence directory: ${OUT}"
