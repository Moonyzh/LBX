# scripts

本目录提供可重复的实验操作。

- `up.sh`：构建并重建两个服务。
- `client.sh`：运行一次客户端调用。
- `verify.sh`：验证两笔固定订单及价格。
- `fault-test.sh`：验证服务停止后的故障边界。
- `collect-result.sh`：生成在线提交包及机器可读结果。
- `grade.sh`：自动评分的第一轮检查。
- `build-base-image.sh`、`export-base-image.sh`：仅供教师准备镜像。

实验 1B（三节点 DHT，详见根目录 `LAB1B-NODE-A.md`）：

- `pack-repo.sh`：把仓库打成压缩包，用于 scp 上传到 CVM（替代 `git clone`）；默认排除 `dist/`、`build/`、`config/runtime/`，加 `--with-dist` 才附带离线镜像包。
- `dht-gen-config.sh`：从 `config/dht-node.yaml.template` 生成每节点运行时配置；三机部署先导出 `NODE_A_IP`/`NODE_B_IP`/`NODE_C_IP`。
- `dht-up.sh`：单机启动三个 DHT 节点 + pricing + trip。
- `dht-up-node.sh a|b|c`：三机部署时每台只启动自己的节点（机器 A 附带 pricing、trip）。
- `dht-verify.sh`：验证三笔订单经 DHT 存取，并打印各节点 put/get 日志。
- `dht-collect-evidence.sh`：SSH 收集三台机器的主机名、compose ps、节点配置与日志。

从仓库根目录用 `bash scripts/<名称>.sh` 运行。云主机账号需已加入 Docker 用户组并重新登录。

