#!/usr/bin/env bash
# 把仓库打成压缩包，用于上传到 CVM。
# 单人部署时用它替代 `git clone <REPO-URL>`：不需要 GitHub/Gitee，也不需要配仓库。
#
# 用法：
#   bash scripts/pack-repo.sh              # 默认不含 dist/，产物约几百 KB
#   bash scripts/pack-repo.sh --with-dist  # 附带 dist/ 里的离线镜像包（约 180 MB，仅当 CVM 拉不到课程镜像时用）
set -euo pipefail

cd "$(dirname "$0")/.."

WITH_DIST=0
case "${1:-}" in
  --with-dist) WITH_DIST=1 ;;
  "") ;;
  *) echo "usage: bash scripts/pack-repo.sh [--with-dist]" >&2; exit 2 ;;
esac

OUT_DIR="dist"
if [ "$WITH_DIST" = "1" ]; then
  OUT="${OUT_DIR}/lab1-mini-dht-with-dist.tar.gz"
else
  OUT="${OUT_DIR}/lab1-mini-dht-src.tar.gz"
fi
mkdir -p "$OUT_DIR"

# 排除：git 元数据、本机 Agent 数据、构建产物、本机生成的运行配置与取证目录
EXCLUDES=(
  --exclude=./.git
  --exclude=./.workbuddy
  --exclude=./build
  --exclude=./config/runtime
  --exclude=./data/evidence
  --exclude=./dist/lab1-mini-dht-src.tar.gz
  --exclude=./dist/lab1-mini-dht-with-dist.tar.gz
  --exclude=./proto/*.pb.cc
  --exclude=./proto/*.pb.h
)
# 默认不带基础镜像压缩包：CVM 能 docker pull 就不需要它
[ "$WITH_DIST" = "1" ] || EXCLUDES+=(--exclude=./dist)

tar -czf "$OUT" "${EXCLUDES[@]}" .

echo "archive : ${OUT}"
echo -n "size    : "; du -h "$OUT" | cut -f1
echo -n "sha256  : "; (sha256sum "$OUT" 2>/dev/null || shasum -a 256 "$OUT") | cut -d' ' -f1
echo
echo "top-level entries:"
tar -tzf "$OUT" | awk -F/ 'NF<=3 && $2!="" {print "  "$2}' | sort -u
echo "files   : $(tar -tzf "$OUT" | grep -vc '/$')"
