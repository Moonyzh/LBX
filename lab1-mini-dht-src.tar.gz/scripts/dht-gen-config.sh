#!/usr/bin/env bash
# Generate one runtime config per DHT node from config/dht-node.yaml.template.
#
# Single machine (default): successor addresses are Compose service names.
# Three CVMs: export the reachable IP of every machine before running, e.g.
#   export NODE_A_IP=<MACHINE-A-IP>
#   export NODE_B_IP=<MACHINE-B-IP>
#   export NODE_C_IP=<MACHINE-C-IP>
# Each machine only needs the variables at generation time; the successor
# chain is node-a -> node-b -> node-c -> node-a.
set -euo pipefail
cd "$(dirname "$0")/.."

NODE_A_ADDR="${NODE_A_IP:-dht-node-a}"
NODE_B_ADDR="${NODE_B_IP:-dht-node-b}"
NODE_C_ADDR="${NODE_C_IP:-dht-node-c}"

mkdir -p config/runtime
gen() {
  local letter="$1" successor="$2"
  local node="node-${letter}"
  sed -e "s/__NODE_ID__/${node}/" -e "s/__SUCCESSOR_ADDR__/${successor}/" \
    "config/dht-node.yaml.template" > "config/runtime/dht-node-${letter}.yaml"
}
gen a "${NODE_B_ADDR}"
gen b "${NODE_C_ADDR}"
gen c "${NODE_A_ADDR}"

echo "DHT runtime configs generated in config/runtime:"
ls -1 config/runtime
