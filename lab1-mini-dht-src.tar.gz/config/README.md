# config

本目录保存 tRPC YAML 配置。

- `pricing-service.yaml`：计价服务监听容器内 8000 端口。
- `trip-service.yaml`：订单服务监听 8000，把计价代理指向 `pricing:8000`；实验 1B 另把 DHT 客户端 `trpc.dht.DhtService` 指向入口节点 `dht-node-a:19001`。
- `ride-client.yaml`：把订单代理指向 `trip:8000`。
- `dht-node.yaml.template`：实验 1B DHT 节点模板（占位符 `__NODE_ID__`、`__SUCCESSOR_ADDR__`），由 `scripts/dht-gen-config.sh` 生成 `runtime/dht-node-{a,b,c}.yaml`。`runtime/` 为生成产物，不要手改。

容器各自拥有网络命名空间，因此多个服务都能监听 8000/19001。服务间地址使用 Compose 服务名，跨机器时由生成脚本写入真实互通 IP，不改成 `127.0.0.1`。

