# 实验一 A 报告：基于 tRPC 的网约车订单微服务

## 1. 小组与环境

- 成员与分工：陈子妍 / 2024214310（独立完成：计价服务实现与参数校验、订单服务跨服务调用、构建与启动、`verify.sh` / `fault-test.sh` 验证、报告与提交）
- 平台：Ubuntu Server 24.04 LTS 64 位（腾讯云 CVM：实例 `ins-2c53zda8`「云计算作业」，南京三区，标准型 SA3，2 核 4 GiB / 5 Mbps，通用型 SSD 云硬盘，按量计费）
- Docker 与 Docker Compose 版本：Docker Engine 与 Compose v2（Ubuntu 24.04 apt 源安装 `docker.io` / `docker-compose-v2`；精确版本号可运行 `docker --version && docker compose version` 补填）
- 基础镜像 ID：`ccr.ccs.tencentyun.com/ccnu-cloudcomputing/trpc-cpp-dev:2026.09`（本地重打标签为 `course/trpc-cpp-dev:2026.09`）

![云主机环境：腾讯云 CVM 实例 ins-2c53zda8（Ubuntu Server 24.04 LTS 64 位，标准型 SA3，2 核 4 GiB，南京三区）](data/evidence/evidence-cvm.png)

## 2. 场景与服务划分

调用图：

```text
ride-client ──CreateRide/GetTrip──> trip-service ──EstimateFare──> pricing-service
                                     │
                                     └── 1A：内存订单表（std::unordered_map）
                                         1B：DHT Put/Get
```

1. **各组件职责与数据**

   - `ride-client`：模拟乘客，只负责发起 `CreateRide` / `GetTrip`，自身不持有状态。
   - `trip-service`：拥有订单数据（内存表，含 trip_id、乘客、路线、距离、时段、报价、状态），负责生成订单号与维护 `WAITING` 状态；向 pricing 取报价，但不复制计价规则。
   - `pricing-service`：唯一维护起步价、里程价与高峰倍率；纯函数式计算，无状态、无下游依赖。

2. **为什么计价逻辑应由 pricing-service 集中维护**

   计价规则是业务核心策略，会随运营调整（改价、分时定价、促销）。若各调用方各自复制公式，改一次价就要改多处，极易不一致且无法审计。集中后规则只有一份实现、一处修改、一套日志；`trip-service` 只消费 `total_fare` 这一结果，天然获得一致性。

3. **Proto 相对于临时拼接 JSON 带来的约束**

   把接口从"临时拼 JSON"升级为强类型契约：字段名、类型、方法名、服务名在编译期固定，双方据此各自生成 stub；修改契约必须改 `.proto` 并重新生成，杜绝"字段名拼错、类型不符"的运行时故障。同时明确了服务边界与序列化格式，使跨语言、跨团队协作可行。

## 3. 正常调用实测

| tripId | 乘客 | 路线 | 距离 km | 时段 | 预估车费 | 状态 | GetTrip 成功 |
|---|---|---|---:|---|---:|---|---|
| trip-000001 | alice | 校园 → 火车站 | 8.5 | 高峰 | 41.04 | WAITING | 是（found=1） |
| trip-000002 | alice | 图书馆 → 医院 | 3.0 | 平峰 | 17.20 | WAITING | 是（found=1） |

验算：(10 + 8.5 × 2.4) × 1.35 = 30.4 × 1.35 = **41.04**；(10 + 3.0 × 2.4) × 1.0 = **17.20** ✓

**实测输出**（`docker compose ps` + `verify.sh` 全部 11 项 PASS，覆盖两笔订单的创建与查询；截图中 `message=trip created after pricing-service quote` 即 trip 侧返回的"报价已发生"证据）：

![订单创建与查询实测输出：docker compose ps 与 verify.sh 全 PASS](data/evidence/evidence-verify.png)

**一次 `CreateRide` 的 RPC 调用顺序：**

1. `ride-client → trip-service`：`CreateRide`（`trpc.ride.trip.TripService/CreateRide`）
2. `trip-service → pricing-service`：`EstimateFare`（`trpc.ride.pricing.PricingService/EstimateFare`，经客户端代理 `PricingServiceServiceProxy` 同步调用）
3. pricing 返回 `total_fare`
4. trip 生成 `trip_id`、写入内存表（状态 `WAITING`）、返回 `create_ok=1`
5. `ride-client → trip-service`：`GetTrip` 按 trip_id 查询，从内存表命中

**关键日志**：trip 侧可见 `trip created after pricing-service quote`；pricing 侧可见 `EstimateFare` 请求记录——两者共同证明跨服务调用真实发生。

## 4. 故障观察

- 停止的服务：先停 `pricing-service`，再停 `trip-service`（由 `scripts/fault-test.sh` 自动执行并恢复）。
- **pricing-service 停止后**：已创建订单仍可查询（`found=1`，报价与状态不变）——订单数据归 trip 所有，`GetTrip` 是纯本地内存读取，不经过 pricing。**新订单在"向 pricing 请求报价"这一步失败**：`CreateRide` 返回 `create_ok=0`（RPC 传输失败），订单不落库。
- **trip-service 停止后**：客户端既不能创建也不能查询订单。查询时 `getaddrinfo` 解析不到 `trip` 主机名（容器已停，docker 内置 DNS 记录消失），`selector domain` 失败，`GetTrip RPC` 失败。
- **依赖关系**：`trip-service → pricing-service` 的**单向、强依赖**，且仅存在于"创建"路径；pricing 不依赖 trip（无状态、无下游）；查询路径不依赖 pricing。pricing 宕机不会丢失已有订单，只阻断新建单。
- **生产改进优先项**：给 `trip → pricing` 的调用增加**超时 + 重试（含退避）+ 熔断**，避免下游慢/挂时拖死上游（本实验即因 merge 线程模型下 handler 内同步调用导致请求超时，改用 separate 线程模型解决）；进一步可加**报价结果缓存/降级**与**监控告警**（RT、错误率、熔断状态）。

**故障实测输出**（`fault-test.sh` 三个 PASS，环境由脚本自动恢复）：

![故障边界实测输出：pricing 停机后旧订单可查、新订单失败；trip 停机后查询失败](data/evidence/evidence-fault.png)

## 5. 与实验 1B 的衔接

1A 中订单存放在 `trip-service` 进程内的内存表（`unordered_map` + 互斥锁），进程重启即丢失。
1B 将其替换为以 `trip:<tripId>` 为 key 的三节点 DHT：

- **写入**：`CreateRide` 拿到报价后 `Put("trip:" + trip_id, 序列化后的订单)`。
- **读取**：`GetTrip` 用 `Get("trip:" + trip_id)` 取回并反序列化。
- **接口不变**：Proto 的 `CreateRide` / `GetTrip` 签名、字段与语义完全不变，只替换 TripStore 这一层实现（map → DHT 客户端封装）；`ride-client` 与 `pricing-service` 完全无感。
- **附带变化**：订单从"进程内存、易失"变为"跨节点、可持久/可复制"，为 1B 的哈希环路由、节点故障与数据迁移留出接口。

## 6. AI/人分工

| AI 帮我做了什么 | 我亲自修改/验证了什么 | 为什么必须由人完成 |
|---|---|---|
| 定位并补齐缺失的 `pricing_service.h/.cc`（按公式实现计价与参数校验）；发现客户端代理类名应为 `...ServiceServiceProxy`（服务名 + ServiceProxy）；分析 `DoConnect target: ,` 根因（direct 选择器不解析主机名 → 改用 domain）；定位 trip 超时根因（merge 线程模型 + handler 内同步调用 → 改用 separate 并补 `handle_thread_num`、补 stdout 日志 sink） | 在 CVM 上执行全部构建/启动/验证命令；亲手拉取基础镜像并打 tag、配置 docker 权限；按结论更新配置文件；运行 `verify.sh` / `fault-test.sh` 并确认结果；填写报告、打包与提交 | 环境与凭证只在人手里（CVM 登录、镜像拉取、docker 组权限）；结果必须在真实环境实测确认；出现新报错需人反馈真实输出，AI 才能定位；报告结论与提交行为由本人负责 |

## 7. 证据清单

截图文件位于 `data/evidence/`，随提交包一并打包（`collect-result.sh` 会打包 `data/` 目录）：

- `data/evidence/evidence-cvm.png` — 云主机环境（腾讯云 CVM 实例 `ins-2c53zda8`，Ubuntu Server 24.04 LTS，标准型 SA3，2 核 4 GiB）；见第 1 节插图。
- `data/evidence/evidence-verify.png` — `docker compose ps`（pricing / trip 均 `Up`，端口 `18001 / 18002 → 8000`）+ 两笔订单的创建与查询输出（`verify.sh` 全 PASS，`41.04` / `17.20`）；见第 3 节插图。
- `data/evidence/evidence-fault.png` — 一次停止服务后的终端输出（`fault-test.sh` 三个 PASS：pricing 停机后旧订单可查、新订单失败；trip 停机后查询失败）；见第 4 节插图。
- **两个服务的关键日志**：由 `scripts/collect-result.sh` 打包时自动抓取——其结果文件内含 `## Service logs` 段（即 `docker compose logs trip pricing` 的完整输出，pricing 的 `EstimateFare` 记录与 trip 的 `created after pricing-service quote` 均在其中）。
- **关键改动**：提交包直接包含修改后的 `src/pricing_service.h/.cc`（新增计价实现）、`src/trip_service.h/.cc` 与 `src/ride_client.cc`（代理类名）、`config/*.yaml`（selector 与线程模型），逐项说明见第 2、4、6 节。
