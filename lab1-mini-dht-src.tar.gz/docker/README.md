# docker

本目录负责镜像和多容器编排。

- `Dockerfile.base`：教师课前构建 tRPC-Cpp 基础镜像；学生不运行。
- `Dockerfile`：基于课程镜像编译四个应用程序（pricing、trip、ride_client、dht_server）。
- `docker-compose.yml`：实验 1A 启动 `pricing`、`trip`；实验 1B 另定义 `dht-node-a/b/c`（容器内均监听 19001，宿主映射 19001/19002/19003），按需运行 `client`。三台 CVM 部署时每台只 `up` 自己的节点服务，节点配置从 `../config/runtime` 挂载。

从仓库根目录优先运行 `bash scripts/up.sh`（1A）或 `bash scripts/dht-up.sh`（1B 单机）。主机映射端口是 18001、18002 和 19001-19003；服务间调用使用 Compose 服务名及容器端口。

